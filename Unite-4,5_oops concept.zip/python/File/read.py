
f = open("employee.txt", "r")

data = f.read()

print(data)

f.close()