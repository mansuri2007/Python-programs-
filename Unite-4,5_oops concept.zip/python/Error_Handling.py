
try:
    a = int(input("Enter first number: "))
    b = int(input("Enter second number: "))

    if a < 0 or b < 0:
        raise ValueError("Negative numbers are not allowed")

    result = a / b

    print("Result:", result)

except ValueError as e:
    print("Value Error:", e)

except ZeroDivisionError:
    print("Error: Cannot divide by zero")

except TypeError:
    print("Error: Invalid data type")

except Exception as e:
    print("Unexpected Error:", e)

else:
    print("Program executed successfully")

finally:
    print("Program execution completed")
