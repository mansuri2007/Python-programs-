class Student:
    college = "LJ University"  # Public class variable

    def __init__(self):
        self.name = "Amaan"       # Public variable
        self._marks = 85          # Protected variable
        self.__password = "1234"  # Private variable

    def display(self):
        print("Name:", self.name)
        print("Marks:", self._marks)
        print("Password:", self.__password)



s1 = Student()

print("Name:", s1.name)
print("Marks:", s1._marks)
print("College:", s1.college)

s1.display()